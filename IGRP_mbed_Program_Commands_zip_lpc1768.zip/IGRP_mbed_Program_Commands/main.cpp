#include "main.h"

//Check Packet Size is Valid
bool packet_Size_Check(int expected_Length, char* recieved_Size)
{
    //Convert char to int for comparison
    int b =atoi(recieved_Size);

#ifdef SERIAL_DEBUG
    pc.printf("m,COMPARING %d (Expected) and %d (Converted Recieved)\n",expected_Length, b);
#endif

    //If the values do not match throw error
    if(expected_Length != b) {
        pc.printf("f,ERROR: Packet size not recognised for this command, packit size %c is invalid\n",recieved_Size);
        return true;
    }

    return false;
}//End of Packet size check function

void FPGA_Reset()
{

#ifdef SERIAL_DEBUG
    pc.printf("m,Reset Low\n");
#endif

    //Set Confirm and Reset Low
    reset_Pin = 0;
    confirm_Pin= 0;

#ifdef SERIAL_DEBUG
    pc.printf("m,Reset High\n");
#endif

    //Set Confirm and High (FPGA Reset)
    reset_Pin = 1;
    confirm_Pin = 1;
    wait(BIT_TIME_INTERVAL);

#ifdef SERIAL_DEBUG
    pc.printf("m,Reset Low\n");
#endif

    //Set Confirm and Reset Low again
    reset_Pin = 0;
    confirm_Pin= 0;
}//end FPGA reset block

//Format and send FPGA packet over D I/O
void send_FPGA_Packet(int motor, int angle)
{
    FPGA_Reset();

    //Create Array for Packet
    int packet[10];

    if(motor ==2) {

        FPGA_Reset();
        return;
    }

    // If motor true, turn table command
    if(motor) {
        //Sets first two bits for turntable command
        packet[0] = 0;
        packet[1] = motor;

#ifdef SERIAL_DEBUG
        pc.printf("m,MOTOR SELECTION 1\n");
#endif
        //Convert 360 to 255 value for FPGA
        angle = (angle*255)/360;

#ifdef SERIAL_DEBUG
        pc.printf("m,CONV ANGLE %3d\n",angle);
#endif

        //Convert decimal to binary string
        int convert = 128;
        int index = 2;
        while (index<10) {

            if (angle >= convert) {
                //"Half" value
                angle = angle - convert;
                //Set packet bit to 1 (The value is higher than the limit so requires binary representation of 1)
                packet[index] = 1;
            } else {
                //Set packet bit to 0 (The value is lower than the limit so requires binary representation of 0)
                packet[index] = 0;
            }

            //Half convert index
            convert = convert / 2;
            //Increment index position
            index++;

#ifdef SERIAL_DEBUG
            pc.printf("m,CONV INDEX %d\n",index);
            pc.printf("m,NEW ANGLE %3d\n",angle);
            pc.printf("m,BIT VALUE %d\n",packet[index]);
#endif
            //End of conversion block
        }
    } else { //Packet Definition for Rack

#ifdef SERIAL_DEBUG
        pc.printf("m,MOTOR SELECTION 0\n");
#endif
        //Rack Operation Select
        if (angle == 0) {
            //Pull Track
            packet[0] = 1;
            packet[1] = 1;
        } else if(angle == 1) {
            //Push Track
            packet[0] = 1;
            packet[1] = 0;
        }

        //Fill rest of packet with all 1s
        for(int i = 2 ; i<10; i++) {
            packet[i] = 1;
        }
    }

#ifdef SERIAL_DEBUG

    for (int p = 0; p<=9; p++) {
        pc.printf("m,%d\n",packet[p]);
    }

#endif

    //Set LED high to indicate start of packet sending
    led4 =1;

    //Variable for pos of packet bit being send
    int current_Bit = 0;

    while(current_Bit<=9) {

#ifdef SERIAL_DEBUG
        pc.printf("m,STAGE\n");
#endif
        led2 = 1;
        mbed_Command = packet[current_Bit];

#ifdef SERIAL_DEBUG
        wait(BIT_TIME_INTERVAL);
#endif

#ifdef SERIAL_DEBUG
        pc.printf("m,CONFIRM\n");
#endif
        led3=1;
        confirm_Pin = 1;

//#ifdef SERIAL_DEBUG
//        wait(BIT_TIME_INTERVAL);
//#endif

#ifdef SERIAL_DEBUG
        pc.printf("m,ACKNOWLEDGE LOW\n");
#endif

        while(!FPGA_Ack) {

            //wait_ms(1);
        }

#ifdef SERIAL_DEBUG
        pc.printf("m,ACKNOWLEDGE HIGH, CLEAR COMMAND AND CONFIRM\n");
#endif

        confirm_Pin = 0;
        mbed_Command=  0;
        current_Bit++;
        led2 =0;
        led3 =0;

#ifdef SERIAL_DEBUG
        wait(BIT_TIME_INTERVAL);
#endif
current_Bit++;
    }

    //Reset all Pins to non-used state
    led2=0;
    led3=0;
    led4=0;
    mbed_Command =0;
    confirm_Pin=0;
}//End of send FPGA Packet function

//Visual Indication of error on MBED
void error_Indicator()
{

    //Error Indicator on LED Strip
    for(int i = 0; i < 10; i++) {
        led1 =1;
        led2 =0;
        led3 =1;
        led4 =0;
        wait(0.5);
        led1 =0;
        led2 =1;
        led3 =0;
        led4 =1;
    }
    //Reset Leds to non used state
    led1=0;
    led2=0;
    led3=0;
    led4=0;

}//End of error Indicator function

//Command Selection
void command_Case()
{
    //Variable for current charecter of the instruction
    char* current_Token;
#ifdef SERIAL_DEBUG
    pc.printf("m,ENTERED COMMAND CASE\n");
#endif

    //Begin Switch case with first charecter (command charecter)
    switch(rx_Buffer[0]) {

        case 'c': //If it is c
#ifdef SERIAL_DEBUG
            pc.printf("m,COMMAND C\n");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                break;
            }

            //Read sensor values
            rgb_sensor.getAllColors(rgbc_sensor_readings);
            //Send sensor values
            pc.printf("c,4,%d,%d,%d,%d,\n",rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);

            break;
        //End Case

        case 'd': //If it is d
#ifdef SERIAL_DEBUG
            pc.printf("m,COMMAND D\n");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                error_Indicator();
                break;
            }

            //Read and send sensor value
            pc.printf("d,1,%d\n",TOF_distance=TOF_sensor.getDistance());

            break;
        //End Case

        case 'r': //If it is r
#ifdef SERIAL_DEBUG
            pc.printf("m,COMMAND R\n");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                error_Indicator();
                break;
            }

            //Read sensor values
            rgb_sensor.getAllColors(rgbc_sensor_readings);
            TOF_distance = TOF_sensor.getDistance();

            //Send sensor values
            pc.printf("r,5,%d,%d,%d,%d,%d\n",TOF_distance,rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);

            break;
        //End Case

        case 's': //If it is s
#ifdef SERIAL_DEBUG
            pc.printf("m,COMMAND S\n");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

#ifdef SERIAL_DEBUG
            pc.printf("m,%s",current_Token);;
#endif

            //Check for valid packet size
            if(packet_Size_Check(2,current_Token)) {
                error_Indicator();
                break;
            }

            //Generate Motor Option
            current_Token = strtok(NULL,",");
            //Convert char to int
            int servo_Motor = atoi(current_Token);

#ifdef SERIAL_DEBUG
            pc.printf("m,Motor Choice: %d\n",servo_Motor);
#endif

            //Generate Motor Angle
            current_Token = strtok(NULL,",");
            //Convert char to int
            int servo_Angle = atoi(current_Token);


#ifdef SERIAL_DEBUG
            pc.printf("m,Angle Choice: %d\n",servo_Angle);
#endif

            //Check that angle is within bounds
            if(servo_Angle < 0 || servo_Angle > 360) {
                pc.printf("f,ERROR: Servo angle out of range, %3d was recieved\n",servo_Angle);
                error_Indicator();
                break;
            }

            //bit 0 = mode bit 1 = use turntable 8 bits angle or 2 = use rack
            send_FPGA_Packet(servo_Motor, servo_Angle);
            
            if(!servo_Motor){
                wait(MOTOR_WAIT);
                
                }
            pc.printf("a,0\n");

            break;
        //End Case

        default: // Default state if command is not recognised
            pc.printf("f,ERROR: Command code not recognised, %c was recieved\n",rx_Buffer[0]);
            error_Indicator();

    }//End of switch/case
}//End of command Case Function


//Serial Rx Interrupt function
void Rx_interrupt()
{
    //Hardware interrupt signal High
    led1 = 1;
#ifdef SERIAL_DEBUG
    pc.printf("m,Interrupt triggered!\n");
#endif

    if(pc.readable()) {
        pc.scanf("%s", &rx_Buffer);

#ifdef SERIAL_DEBUG
        pc.printf("m,Charecter Captured!\n");
#endif
    }
#ifdef SERIAL_DEBUG
    pc.printf("m,%s\n",rx_Buffer);
#endif


    //Call to Command Selection Function
    command_Case();

    //Hardware interrupt signal low
    led1 = 0;
}//End of Rx_interrupt Function

//Main Method
int main()
{

    //Initialise Sensors and Serial Line
    TOF_sensor.VL6180_Init();
    rgb_sensor.enablePowerAndRGBC();
    rgb_sensor.setIntegrationTime(INT_TIME);
    pc.baud(BAUDRATE);
    pc.attach(&Rx_interrupt, Serial::RxIrq);

    //infinite loop
    while(1) {

#ifdef SERIAL_DEBUG
        pc.printf("m,IN LOOP\n");
#endif
        //Display Waiting indicator

        led1 = 1;
        wait(0.2);
        led1 =0;
        led2 = 1;
        wait(0.2);
        led2=0;
        led3 = 1;
        wait(0.2);
        led3=0;
        led4=1;
        wait(0.2);

#ifdef TEST_FPGA
        pc.printf("Sending Packet 0\n");
        send_FPGA_Packet(1,0);
        pc.printf("Sending Packet 0\n");
        wait(10);
        pc.printf("Sending Packet 360\n");
        send_FPGA_Packet(1,360);
        pc.printf("Sending Packet 360\n");
        wait(10);
        pc.printf("Sending Packet 180\n");
        send_FPGA_Packet(1,180);
        pc.printf("Sending Packet 180\n");
        wait(10);

#endif
        led3 =1;
        led4 = 0;
        wait(0.2);
        led2= 1;
        led3 = 0;
        wait(0.2);
        led1=1;
        led2=0;
        wait(0.2);

    } //end of while loop
}//end of main method