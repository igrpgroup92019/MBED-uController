#include "mbed.h"
#include "VL6180.h"
#include "TCS3472_I2C.h"
#include "main.h"

//Object Defintions
TCS3472_I2C rgb_sensor(p9,p10);
VL6180 TOF_sensor(p28,p27);

//Can be used for hardware status
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

//Serial definitions and setup
Serial pc(USBTX,USBRX); //PC usb Serial
char rx_buffer[BUFFERSIZE+1];

//Initialise data variables
int rgbc_sensor_readings[4]; //Array for 5 sensor data points
int TOF_distance = 0;


//missing Acknowledge message
void command_Case()
{
    //pc.printf("%c",rx_buffer[0]);
    //Begin Switch case with first charecter (command charecter)
    switch(rx_buffer[0]) {

        //If it is c
        case 'c':

            rgb_sensor.getAllColors(rgbc_sensor_readings);
            //pc.printf("THIS IS C\n");
            pc.printf("c,4,%d,%d,%d,%d,\n",rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);
            //pc.printf("%c,%c,%c,%c",rx_buffer[0],rx_buffer[1],rx_buffer[2],rx_buffer[3]);

            break;
        //End Case

        //If it is d
        case 'd':
            //pc.printf("THIS IS D\n");
            pc.printf("d,1,%d\n",TOF_distance=TOF_sensor.getDistance());

            break;
        //End Case

        //If it is r
        case 'r':

            rgb_sensor.getAllColors(rgbc_sensor_readings);
            TOF_distance = TOF_sensor.getDistance();
            //pc.printf("THIS IS R\n");
            pc.printf("r,5,%d,%d,%d,%d,%d\n",TOF_distance,rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);

            break;
        //End Case

        //If it is s
        case 's':
            //pc.printf("THIS IS S\n");
            break;
        //End Case

        default:
            //pc.printf("THIS IS A DEFAULT CASE\n");
            pc.printf("f,ERROR: Command code not recognised, %c was recieved\n",rx_buffer[0]);
    }//End of switch/case
}//End of command Case Function

//Serial Rx Interrupt function
void Rx_interrupt()
{
    led1 = 1;
    /* int bufferpos = 0;
    * while(pc.readable()) {
    *     rx_buffer[bufferpos]=pc.getc();
    *     //pc.printf("%c",rx_buffer[bufferpos]);
    *     bufferpos++;
    * }
    */
    //wait(1);
    if(pc.readable()) {
        pc.scanf("%s", &rx_buffer);
    }

    command_Case();

    /*for (int i=0; i<bufferpos; i++){
        rx_buffer[i] = NULL;
        }*/

    led1 = 0;
}

//Main Method
int main()
{

    //Initialise Sensors and Serial Line
    TOF_sensor.VL6180_Init();
    rgb_sensor.enablePowerAndRGBC();
    rgb_sensor.setIntegrationTime(INT_TIME);
    pc.baud(BAUDRATE);
    pc.attach(&Rx_interrupt, Serial::RxIrq);

    //infinite loop
    while(1) {
        led4 =0;
        led2 = 1;
        wait(0.5);
        led2=0;
        led3 = 1;
        wait(0.5);
        led3=0;
        led4=1;
        wait(0.5);

    } //end of while loop
}//end of main method