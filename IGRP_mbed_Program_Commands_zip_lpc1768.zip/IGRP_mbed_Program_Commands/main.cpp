#include "main.h"

//Check Packet Size is Valid
bool packet_Size_Check(int expected_Length, char* recieved_Size)
{

    int b =atoi(recieved_Size);

#ifdef SERIAL_DEBUG
    pc.printf("COMPARING %d (Expected) and %d (Converted Recieved)\n\r",expected_Length, b);
#endif
    //If the values do not match throw error
    if(expected_Length != b) {
        pc.printf("f,ERROR: Packet size not recongised for this command, packit size %c is invalid\n",recieved_Size);
        return true;
    }

    return false;
}//End of Packet size check function

//Format and send FPGA packet over D I/O
void send_FPGA_Packet(int motor, int angle)
{
#ifdef SERIAL_DEBUG
    pc.printf("Reset Low\n\r");
#endif
    //Set Confirm and Reset Low
    reset_Pin = 0;
    confirm_Pin= 0;

#ifdef SERIAL_DEBUG
    pc.printf("Reset High\n\r");
#endif

    //Set Confirm and High (FPGA Reset)
    reset_Pin = 1;
    confirm_Pin = 1;
    wait(BIT_TIME_INTERVAL);

#ifdef SERIAL_DEBUG
    pc.printf("Reset Low\n\r");
#endif

    //Set Confirm and Reset Low
    reset_Pin = 0;
    confirm_Pin= 0;

    led4 =1;
    //Create Array for Packet
    bool packet[10];

    //Mode Set: 0 Normal Maintance 1
    packet[0] = 1;
    //Motor Select
    packet[1] = motor;

    if(motor) {
        //Packet Definition for Turntable

        //Define point to start storing conversion
        int conv_Index = 9;
        //convert decimal to binary string
        while (angle != 0) {
            packet[conv_Index] = angle % 2;
            angle = angle /2;
            conv_Index--;

        }
    } else {
        //Packet Definition for Rack
        packet[2] = angle;
        for(int i = 3 ; i<10; i++) {
            packet[i] = 1;
        }

    }

    //Loop for length of packet
    for (int i =0; i < 10 ; i++) {
#ifdef SERIAL_DEBUG
        pc.printf("%d\t",packet[i]);
        pc.printf("Lower Confirm, clear command\t");
#endif

        //Set Confirm and Command Low
        led2 =0;
        confirm_Pin = 0;
        led3=0;
        mbed_Command = 0;
        wait(BIT_TIME_INTERVAL);

#ifdef SERIAL_DEBUG
        pc.printf("Stage\t");
#endif

        //Stage Bit of Packet
        led2 = 1;
        mbed_Command = packet[i];
        wait(BIT_TIME_INTERVAL);

#ifdef SERIAL_DEBUG
        pc.printf("Comfirm\t");
#endif
        //Set Confirm High (This bit is correct)
        led3=1;
        confirm_Pin = 1;
        wait(BIT_TIME_INTERVAL);

    }

    //Reset all Pins to non-used state
    led2=0;
    led3=0;
    led4=0;
    mbed_Command =0;
    confirm_Pin=0;
}//End of send FPGA Packet function

//Visual Indication of error on MBED
void error_Indicator()
{

    //Error Indicator on LED Strip
    for(int i =0; i <10; i++) {
        led1 =1;
        led2 =0;
        led3 =1;
        led4 =0;
        wait(0.5);
        led1 =0;
        led2 =1;
        led3 =0;
        led4 =1;
    }
    led1=0;
    led2=0;
    led3=0;
    led4=0;

}//End of error Indicator function

//Command Selection
void command_Case()
{
    char* current_Token;
#ifdef SERIAL_DEBUG
    pc.printf("Entered Command Case\n\r");
#endif
    //Begin Switch case with first charecter (command charecter)
    switch(rx_Buffer[0]) {

        //If it is c
        case 'c':
#ifdef SERIAL_DEBUG
            pc.printf("COMMAND C\n\r");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                break;
            }

            //Read sensor values
            rgb_sensor.getAllColors(rgbc_sensor_readings);
            //Send sensor values
            pc.printf("c,4,%d,%d,%d,%d,\n",rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);

            break;
        //End Case

        //If it is d
        case 'd':
#ifdef SERIAL_DEBUG
            pc.printf("COMMAND D\n\r");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                error_Indicator();
                break;
            }

            //Read and send sensor value
            pc.printf("d,1,%d\n",TOF_distance=TOF_sensor.getDistance());

            break;
        //End Case

        //If it is r
        case 'r':
#ifdef SERIAL_DEBUG
            pc.printf("COMMAND R\n\r");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");

            //Check for valid packet size
            if(packet_Size_Check(0,current_Token)) {
                error_Indicator();
                break;
            }

            //Read sensor values
            rgb_sensor.getAllColors(rgbc_sensor_readings);
            TOF_distance = TOF_sensor.getDistance();

            //Send sensor values
            pc.printf("r,5,%d,%d,%d,%d,%d\n",TOF_distance,rgbc_sensor_readings[0],rgbc_sensor_readings[1],rgbc_sensor_readings[2],rgbc_sensor_readings[3]);

            break;
        //End Case

        //If it is s
        case 's':
#ifdef SERIAL_DEBUG
            pc.printf("COMMAND S\n\r");
#endif
            //Throw away first token
            current_Token = strtok(rx_Buffer,",");
            //get next needed token
            current_Token = strtok(NULL,",");
            pc.printf("%s",current_Token);;

            //Check for valid packet size
            if(packet_Size_Check(2,current_Token)) {
                error_Indicator();
                break;
            }

            //Generate Motor Option
            int servo_Motor = atoi(strtok(NULL,","));
#ifdef SERIAL_DEBUG
            pc.printf("Motor Choice: %d\n\r",servo_Motor);
#endif

            //Check that it is an expected value
            //0 == Rack, 1 == Turntable
            if(servo_Motor != 0 || servo_Motor != 1) {
                pc.printf("f,ERROR: Servo selection out of range, %c was recieved\n",servo_Motor);
                error_Indicator();
                break;
            }

            //Generate Motor Angle
            int servo_Angle = atoi(strtok(NULL,","));

#ifdef SERIAL_DEBUG
            pc.printf("Angle Choice: %d\n\r",servo_Motor);
#endif

            //Check that it is an expected value
            if(servo_Angle < 0 || servo_Angle > 255) {
                pc.printf("f,ERROR: Servo angle out of range, %c was recieved\n",servo_Angle);
                error_Indicator();
                break;
            }

            //bit 0 = mode bit 1 = use turntable 8 bits angle or 2 = use rack
            send_FPGA_Packet(servo_Motor, servo_Angle);

            break;
        //End Case

        default:
            pc.printf("f,ERROR: Command code not recognised, %c was recieved\n",rx_Buffer[0]);
            error_Indicator();

    }//End of switch/case
}//End of command Case Function


//Serial Rx Interrupt function
void Rx_interrupt()
{
    //Hardware interrupt signal High
    led1 = 1;
#ifdef SERIAL_DEBUG
    pc.printf("Interrupt triggered!\n\r");
#endif

    if(pc.readable()) {
        pc.scanf("%s", &rx_Buffer);

#ifdef SERIAL_DEBUG
        pc.printf("Charecter Captured!\n\r");
#endif
    }

    //Call to Command Selection Function
    command_Case();

    //Hardware interrupt signal low
    led1 = 0;
}//End of Rx_interrupt Function

//Main Method
int main()
{

    //Initialise Sensors and Serial Line
    TOF_sensor.VL6180_Init();
    rgb_sensor.enablePowerAndRGBC();
    rgb_sensor.setIntegrationTime(INT_TIME);
    pc.baud(BAUDRATE);
    pc.attach(&Rx_interrupt, Serial::RxIrq);

    //infinite loop
    while(1) {
        //Display Waiting indicator

        led1 = 1;
        wait(0.2);
        led1 =0;
        led2 = 1;
        wait(0.2);
        led2=0;
        led3 = 1;
        wait(0.2);
        led3=0;
        led4=1;
        wait(0.2);

        //pc.printf("Sending Packet\n\r");
        //send_FPGA_Packet(1,255);


        led3 =1;
        led4 = 0;
        wait(0.2);
        led2= 1;
        led3 = 0;
        wait(0.2);
        led1=1;
        led2=0;
        wait(0.2);

    } //end of while loop
}//end of main method