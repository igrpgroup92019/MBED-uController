#include "mbed.h"
//#include "VL6180.h"
#include "TCS3472_I2C.h"

//mbed Defintions

#define BAUDRATE 9600
#define BUFFERSIZE 255 //Set size of Serial buffer

//Colour Sensor Definitions
#define INT_TIME 50

//TOF Sensor Definitions