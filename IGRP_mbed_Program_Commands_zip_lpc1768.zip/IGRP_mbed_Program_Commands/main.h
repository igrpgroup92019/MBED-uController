#include "mbed.h"
#include "VL6180.h"
#include "TCS3472_I2C.h"

//mbed Defintions

#define SERIAL_DEBUG
#define BAUDRATE 9600
#define BUFFERSIZE 16 //Set size of Serial buffer

//Colour Sensor Definitions
#define INT_TIME 50

//TOF Sensor Definitions

//FPGA Definitions
#define MBED_COMMAND_PIN p24
#define CONFIRM_PIN p23
#define RESET_PIN p22
#define FPGA_WAIT_PIN p21
#define BIT_TIME_INTERVAL 0.5

//Object Defintions
TCS3472_I2C rgb_sensor(p9,p10);
VL6180 TOF_sensor(p28,p27);

//Can be used for hardware status
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

//FPGA to Mbed Pins
DigitalOut mbed_Command(MBED_COMMAND_PIN);
DigitalOut confirm_Pin(CONFIRM_PIN);
DigitalOut reset_Pin(p22);
DigitalIn  FPGA_Wait(FPGA_WAIT_PIN);

//Serial definitions and setup
Serial pc(USBTX,USBRX); //PC usb Serial
char rx_Buffer[BUFFERSIZE+1];

//Initialise data variables
int rgbc_sensor_readings[4]; //Array for 5 sensor data points
int TOF_distance = 0;