#include "mbed.h"
#include "VL6180.h"
#include "TCS3472_I2C.h"
#include "main.h"

//Object Defintions
TCS3472_I2C rgb_sensor(p9,p10);
VL6180 TOF_sensor(p28,p27);
Serial pc(USBTX,USBRX);

//Variable Definitions
int sensor_readings[5];
char* serialWritePacket;


int main() {
    
    //Initialise Sensors and Serial Line
    TOF_sensor.VL6180_Init();
    rgb_sensor.enablePowerAndRGBC();
    rgb_sensor.setIntegrationTime(INT_TIME);
    pc.baud(BAUDRATE);
    
    
    //Construst Memory Space for data packet
    //serialWritePacket = (char*) malloc(PACKETSIZE*sizeof(char));
    
    while(1) {
        //Read RGB Sensor to first 4 array elements
        rgb_sensor.getAllColors(sensor_readings);
        
        //Read TOF Sensor to 5 element of array
        sensor_readings[4]= TOF_sensor.getDistance();
        
        //Formant Data Packet into .CSV style ,sensor_readings[4]
        pc.printf("%d,%d,%d,%d,%d\n",sensor_readings[0],sensor_readings[1],sensor_readings[2],sensor_readings[3],sensor_readings[4]);
            
        //Print packet to serial line  
        wait(1);

    }
}
