#include "mbed.h"
//#include "VL6180.h"
#include "TCS3472_I2C.h"

//mbed Defintions

#define BAUDRATE 9600
//#define PACKETSIZE 10

//Colour Sensor Definitions
#define INT_TIME 100

//TOF Sensor Definitions