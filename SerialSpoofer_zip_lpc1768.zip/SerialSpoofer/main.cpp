#include "mbed.h"

#include "main.h"

//Object Defintions

Serial pc(USBTX,USBRX);

//Variable Definitions
int sensor_readings[5];
char* serialWritePacket;


int main() {
    
    //Initialise Sensors and Serial Line
    pc.baud(BAUDRATE);
    
    
    //Construst Memory Space for data packet
    serialWritePacket = (char*) malloc(PACKETSIZE*sizeof(char));
    
    while(1) {
        sensor_readings[0]=rand();
        sensor_readings[1]=rand();
        sensor_readings[2]=rand();
        sensor_readings[3]=rand();
        sensor_readings[4]=rand();
        
        //Formant Data Packet into .CSV style ,sensor_readings[4]
        sprintf(serialWritePacket, "%d,%d,%d,%d,%d",sensor_readings[0],sensor_readings[1],sensor_readings[2],sensor_readings[3],sensor_readings[4]);
        //pc.printf("%d,%d,%d,%d,%d",sensor_readings[0],sensor_readings[1],sensor_readings[2],sensor_readings[3],sensor_readings[4]);
        pc.printf(serialWritePacket);
        //Print packet to serial line  
        wait(1);

    }
}
